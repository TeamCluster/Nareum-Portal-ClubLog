"""동아리 목록(club_list.xlsx) 관련 데이터 처리.

라우트에 흩어져 있던 pandas 엑셀 입출력을 서비스 계층으로 모았습니다.
"""
import os

import pandas as pd

from config import CLUB_LIST_PATH
from utils.sorting import sort_key_korean_first


def get_clubs():
    """동아리 목록을 [{name, category}, ...] 형태로 반환 (한글 우선 정렬)."""
    if not os.path.exists(CLUB_LIST_PATH):
        return []

    df = pd.read_excel(CLUB_LIST_PATH)
    df.columns = df.columns.str.strip()

    clubs = [
        {"name": str(row["동아리 명"]), "category": str(row["동아리 분야"])}
        for _, row in df.iterrows()
    ]
    clubs.sort(key=lambda c: sort_key_korean_first(c["name"]))
    return clubs


def get_club_dict():
    """{동아리명: 분야} 딕셔너리 반환. 프론트의 분야 자동 채움에 사용."""
    return {c["name"]: c["category"] for c in get_clubs()}


def add_club(name: str, category: str):
    """동아리 추가. (성공여부, 메시지) 튜플 반환."""
    name = (name or "").strip()
    category = (category or "").strip()
    if not name or not category:
        return False, "동아리 이름과 분야를 모두 입력해주세요."

    df = (
        pd.read_excel(CLUB_LIST_PATH)
        if os.path.exists(CLUB_LIST_PATH)
        else pd.DataFrame(columns=["동아리 명", "동아리 분야"])
    )
    df.columns = df.columns.str.strip()

    if name in df["동아리 명"].astype(str).values:
        return False, "이미 존재하는 동아리입니다."

    df = pd.concat(
        [df, pd.DataFrame([{"동아리 명": name, "동아리 분야": category}])],
        ignore_index=True,
    )
    _save_sorted(df)
    return True, f"'{name}' 동아리가 추가되었습니다."


def delete_club(name: str):
    """동아리 삭제. (성공여부, 메시지) 튜플 반환."""
    if not os.path.exists(CLUB_LIST_PATH):
        return False, "동아리 목록 파일을 찾을 수 없습니다."

    df = pd.read_excel(CLUB_LIST_PATH)
    df.columns = df.columns.str.strip()
    df = df[df["동아리 명"].astype(str) != name]
    _save_sorted(df)
    return True, f"'{name}' 동아리가 삭제되었습니다."


def get_clubs_with_auth():
    """인증번호 컬럼을 포함한 DataFrame 반환. 주간 입력 검증에 사용.

    인증번호 컬럼이 없으면 0000 으로 채우고, 항상 4자리 문자열로 정규화합니다.
    """
    if not os.path.exists(CLUB_LIST_PATH):
        df = pd.DataFrame(columns=["동아리 명", "동아리 분야", "인증번호"])
        df.to_excel(CLUB_LIST_PATH, index=False)
        return df

    df = pd.read_excel(CLUB_LIST_PATH)
    df.columns = df.columns.str.strip()
    if "인증번호" not in df.columns:
        df["인증번호"] = "0000"
    df["인증번호"] = df["인증번호"].fillna("0000").astype(str).str.zfill(4)
    return df


def _save_sorted(df):
    """한글 우선 정렬 후 엑셀로 저장."""
    df = df.copy()
    df["_sort"] = df["동아리 명"].apply(sort_key_korean_first)
    df = df.sort_values(by="_sort").drop(columns=["_sort"])
    df.to_excel(CLUB_LIST_PATH, index=False)