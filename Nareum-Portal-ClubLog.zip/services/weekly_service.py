"""주간 활동 여부(club_weekly.xlsx) 관련 데이터 처리.

기존 app.py 의 weekly() 라우트는 정의되지 않은 club_dict / now 를 참조해
실행 시 에러가 났습니다. 주차 계산도 두 곳에서 서로 다르게(%U vs isocalendar)
구현돼 있었는데, 여기서 isocalendar 기준으로 통일했습니다.
"""
import os
from datetime import datetime, timedelta
from io import BytesIO

import pandas as pd

from config import WEEKLY_LOG_PATH
from services.club_service import get_clubs_with_auth

WEEKLY_COLUMNS = ["동아리 명", "활동 주차", "활동 여부", "작성 일시", "분야"]


def get_target_monday(now: datetime) -> datetime:
    """등록 대상 주의 월요일을 반환.

    토/일요일이면 '다음 주' 월요일, 월~금이면 '이번 주' 월요일.
    """
    wd = now.weekday()  # 월=0 ... 일=6
    if wd in (5, 6):  # 토/일
        days = (7 - wd) % 7 or 7
        target = now + timedelta(days=days)
    else:
        target = now - timedelta(days=wd)
    return target.replace(hour=0, minute=0, second=0, microsecond=0)


def within_submission_window(now: datetime) -> bool:
    """입력 가능 기간: 토요일 00:00 ~ 금요일 23:59:59."""
    mon = get_target_monday(now)
    start = mon - timedelta(days=2)  # 직전 토요일 00:00
    end = mon + timedelta(days=4, hours=23, minutes=59, seconds=59)  # 금요일 23:59:59
    return start <= now <= end


def get_week_info():
    """현재 등록 대상 주 정보를 dict 로 반환 (프론트 화면 표시용)."""
    now = datetime.now()
    mon = get_target_monday(now)
    days = [mon + timedelta(days=i) for i in range(7)]  # 월~일
    year, week_num, _ = mon.isocalendar()

    return {
        "week_label": f"{year}년 {week_num}주차",
        "day_labels": [d.day for d in days],  # 각 요일의 '일(day)' 숫자
        "monday": mon.strftime("%Y-%m-%d"),
        "submission_open": within_submission_window(now),
    }


def _read_weekly():
    """주간 로그 엑셀을 DataFrame 으로 읽기. 없으면 빈 파일 생성."""
    if not os.path.exists(WEEKLY_LOG_PATH):
        df = pd.DataFrame(columns=WEEKLY_COLUMNS)
        df.to_excel(WEEKLY_LOG_PATH, index=False)
        return df
    return pd.read_excel(WEEKLY_LOG_PATH)


def create_weekly(club_name: str, activity_status: str, auth_code: str):
    """주간 활동 여부 한 건 등록. (성공여부, 메시지, 결과dict) 반환."""
    now = datetime.now()
    if not within_submission_window(now):
        return False, "현재는 입력 가능 기간(토요일~금요일)이 아닙니다.", None

    club_name = (club_name or "").strip()
    auth_code = (auth_code or "").strip()

    clubs_df = get_clubs_with_auth()
    row = clubs_df[clubs_df["동아리 명"].astype(str) == club_name]
    if row.empty:
        return False, "동아리 명을 선택해 주세요.", None

    real_auth = str(row.iloc[0]["인증번호"]).zfill(4)
    category = row.iloc[0].get("동아리 분야", "")

    if not (auth_code.isdigit() and len(auth_code) == 4):
        return False, "동아리 인증번호는 숫자 4자리여야 합니다.", None
    if auth_code != real_auth:
        return False, "동아리 인증번호가 올바르지 않습니다.", None

    week = get_week_info()
    week_label = week["week_label"]

    df = _read_weekly()
    df = pd.concat(
        [df, pd.DataFrame([{
            "동아리 명": club_name,
            "활동 주차": week_label,
            "활동 여부": activity_status,
            "작성 일시": now.strftime("%Y-%m-%d %H:%M:%S"),
            "분야": category,
        }])],
        ignore_index=True,
    )
    df.to_excel(WEEKLY_LOG_PATH, index=False)

    result = {
        "week": week_label,
        "category": str(category),
        "club": club_name,
        "activity": activity_status,
    }
    return True, "주간 활동 여부가 저장되었습니다.", result


def get_weekly_logs():
    """주간 입력 기록 전체를 dict 리스트로 반환 (관리자 설정 페이지용)."""
    df = _read_weekly()
    return df.fillna("").astype(str).to_dict("records")


def export_excel():
    """현재 주간 로그를 엑셀 바이트로 반환. (BytesIO, 파일명) 튜플."""
    df = _read_weekly()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"동아리 주간 활동 여부_{timestamp}.xlsx"

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return output, filename