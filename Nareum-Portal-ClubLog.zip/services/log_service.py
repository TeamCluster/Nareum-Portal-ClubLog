"""활동일지(club_log.xlsx) 관련 데이터 처리."""
import os
from datetime import date, datetime
from io import BytesIO

import pandas as pd

from config import DIARY_LOG_PATH

# 엑셀에 저장되는 컬럼 순서 (실제 데이터 파일 기준)
LOG_COLUMNS = [
    "동아리 분야", "동아리 명", "활동 일자", "시작 시간", "종료 시간",
    "참가자", "활동 내용", "작성자", "총 인원수",
    "초등 남", "초등 여", "중등 남", "중등 여",
    "고등 남", "고등 여", "후기 남", "후기 여", "기록일시",
]


def _read_log():
    """로그 엑셀을 DataFrame 으로 읽기. 없으면 빈 파일 생성."""
    if not os.path.exists(DIARY_LOG_PATH):
        df = pd.DataFrame(columns=LOG_COLUMNS)
        df.to_excel(DIARY_LOG_PATH, index=False)
        return df

    df = pd.read_excel(DIARY_LOG_PATH)
    # 호환성: 없는 컬럼은 빈 값으로 채움
    for col in LOG_COLUMNS:
        if col not in df.columns:
            df[col] = ""
    return df


def get_logs():
    """전체 활동일지를 기록일시 최신순 dict 리스트로 반환."""
    df = _read_log()
    if df.empty:
        return []

    if "기록일시" in df.columns:
        df = df.sort_values(by="기록일시", ascending=False)

    # 날짜/시각을 문자열로 정규화 (JSON 직렬화 + 화면 표시용)
    df["활동 일자"] = (
        pd.to_datetime(df["활동 일자"], errors="coerce")
        .dt.strftime("%Y-%m-%d")
        .fillna("")
    )
    df = df.fillna("")
    return df.astype(str).to_dict("records")


def create_log(data: dict):
    """활동일지 한 건 작성. (성공여부, 메시지, 결과dict) 반환.

    data 는 프론트에서 보낸 JSON 으로, 아래 키를 기대합니다.
      category, club_name, activity_year/month/day,
      start_hour/minute, end_hour/minute,
      participants, author, activity_content,
      element_man/woman, middle_man/woman, high_man/woman, univ_man/woman
    """
    try:
        category = data.get("category", "")
        club_name = data.get("club_name", "")
        year = int(data["activity_year"])
        month = int(data["activity_month"])
        day = int(data["activity_day"])
        start_hour = int(data["start_hour"])
        start_minute = int(data["start_minute"])
        end_hour = int(data["end_hour"])
        end_minute = int(data["end_minute"])
        participants = data.get("participants", "")
        author = data.get("author", "")
        content = data.get("activity_content", "")

        counts = {
            key: int(data.get(key, 0) or 0)
            for key in (
                "element_man", "element_woman", "middle_man", "middle_woman",
                "high_man", "high_woman", "univ_man", "univ_woman",
            )
        }
    except (KeyError, ValueError, TypeError):
        return False, "입력값 형식이 올바르지 않습니다.", None

    total = sum(counts.values())
    if total == 0:
        return False, "총 인원수가 0명일 수 없습니다.", None

    # 오후 시간 보정 (예: '1'시 입력 -> 13시). 기존 로직 유지.
    if start_hour < 9:
        start_hour += 12
    if end_hour < 9:
        end_hour += 12

    if start_hour * 60 + start_minute >= end_hour * 60 + end_minute:
        return False, "시작 시간은 종료 시간 이전이어야 합니다.", None

    try:
        activity_date = date(year, month, day)
    except ValueError:
        return False, "활동 일자가 올바르지 않습니다.", None

    row = {
        "동아리 분야": category,
        "동아리 명": club_name,
        "활동 일자": activity_date,
        "시작 시간": f"{start_hour}:{start_minute:02d}",
        "종료 시간": f"{end_hour}:{end_minute:02d}",
        "참가자": participants,
        "활동 내용": content,
        "작성자": author,
        "총 인원수": total,
        "초등 남": counts["element_man"], "초등 여": counts["element_woman"],
        "중등 남": counts["middle_man"], "중등 여": counts["middle_woman"],
        "고등 남": counts["high_man"], "고등 여": counts["high_woman"],
        "후기 남": counts["univ_man"], "후기 여": counts["univ_woman"],
        "기록일시": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    # 전체를 읽어 concat 후 저장 — 시트 이름에 의존하던 기존 append 방식보다 안전
    df = _read_log()
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    df.to_excel(DIARY_LOG_PATH, index=False)

    result = {
        "club": club_name,
        "category": category,
        "date": f"{year}-{month:02d}-{day:02d}",
        "people": total,
    }
    return True, "활동일지가 저장되었습니다.", result


def delete_log(timestamp: str):
    """기록일시(timestamp) 기준으로 활동일지 한 건 삭제."""
    if not timestamp:
        return False, "삭제할 항목을 식별할 수 없습니다."
    if not os.path.exists(DIARY_LOG_PATH):
        return False, "로그 파일을 찾을 수 없습니다."

    df = pd.read_excel(DIARY_LOG_PATH)

    # 엑셀 저장/읽기 과정에서 형식이 바뀔 수 있어 문자열로 통일해 비교
    compare = pd.to_datetime(df["기록일시"], errors="coerce").dt.strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    # timestamp 와 일치하지 않거나, 파싱 실패(NaT)한 행은 보존
    keep = (compare != timestamp) | compare.isna()
    filtered = df[keep].copy()

    if "활동 일자" in filtered.columns:
        filtered["활동 일자"] = pd.to_datetime(
            filtered["활동 일자"], errors="coerce"
        ).dt.date

    filtered.to_excel(DIARY_LOG_PATH, index=False)
    return True, "활동 이력이 삭제되었습니다."


def get_dashboard_stats(total_club_count: int):
    """관리자 대시보드용 통계 반환."""
    df = _read_log()
    today_str = datetime.now().strftime("%Y-%m-%d")

    today_count = 0
    recent = []
    if not df.empty and "활동 일자" in df.columns:
        normalized = pd.to_datetime(df["활동 일자"], errors="coerce").dt.strftime(
            "%Y-%m-%d"
        )
        today_count = int((normalized == today_str).sum())

        recent_df = df.tail(5).iloc[::-1].copy()
        recent_df["활동 일자"] = pd.to_datetime(
            recent_df["활동 일자"], errors="coerce"
        ).dt.strftime("%Y-%m-%d").fillna("")
        recent = recent_df.fillna("").astype(str).to_dict("records")

    return {
        "today_activity_count": today_count,
        "total_club_count": total_club_count,
        "recent_logs": recent,
    }


def export_excel():
    """현재 로그를 엑셀 바이트로 반환. (BytesIO, 파일명) 튜플."""
    df = _read_log()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"동아리 일지_{timestamp}.xlsx"

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return output, filename