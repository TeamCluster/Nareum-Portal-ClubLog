"""애플리케이션 설정.

기존 app.py 상단에 흩어져 있던 경로/비밀번호 상수를 한곳에 모았습니다.
운영 환경에서는 환경변수로 값을 덮어쓸 수 있습니다.
"""
import os

# backend/ 디렉터리의 절대 경로
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# 엑셀 데이터 파일이 저장되는 폴더 (DB 역할)
DATA_FOLDER = os.path.join(BASE_DIR, "data")

CLUB_LIST_PATH = os.path.join(DATA_FOLDER, "club_list.xlsx")
DIARY_LOG_PATH = os.path.join(DATA_FOLDER, "club_log.xlsx")
WEEKLY_LOG_PATH = os.path.join(DATA_FOLDER, "club_weekly.xlsx")

# 세션 서명용 비밀키 / 관리자 비밀번호
# 운영 시 반드시 환경변수(SECRET_KEY, ADMIN_PASSWORD)로 주입하세요.
SECRET_KEY = os.environ.get("SECRET_KEY", "Skfma20601318")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "skfma2013")

# React(Vite) 개발 서버 주소 — CORS 허용 대상
FRONTEND_ORIGIN = os.environ.get("FRONTEND_ORIGIN", "http://localhost:5173")