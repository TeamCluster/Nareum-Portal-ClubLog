﻿"""나름 동아리 활동일지 — Flask JSON API.

기존 app.py 는 render_template 로 HTML 을 직접 그렸지만,
이 버전은 모든 응답을 JSON 으로 내려주는 순수 API 서버입니다.
화면(폼/모달/표)은 React(Vite) 프론트엔드가 담당합니다.
"""
from functools import wraps

from flask import Flask, jsonify, request, send_file, session
from flask_cors import CORS

import config
from services import club_service, log_service, weekly_service

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

# 세션 쿠키 설정 — React 개발 서버(다른 포트)에서 쿠키를 주고받기 위함.
# localhost 끼리는 same-site 라 Lax 로 충분합니다.
# 운영 환경에서 프론트/백 도메인이 다르면 SAMESITE="None" + SECURE=True 로 바꾸세요.
app.config.update(
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_HTTPONLY=True,
)

# 프론트엔드 주소만 CORS 허용 + 쿠키 동반 허용
CORS(app, origins=[config.FRONTEND_ORIGIN], supports_credentials=True)


def login_required(view):
    """관리자 로그인 여부를 확인하는 데코레이터."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return jsonify({"error": "로그인이 필요합니다."}), 401
        return view(*args, **kwargs)
    return wrapped


# ======================================================================
#  공개 API — 활동일지
# ======================================================================
@app.get("/api/clubs")
def api_clubs():
    """동아리 목록 반환. (분야 자동 채움용 dict 도 함께 제공)"""
    clubs = club_service.get_clubs()
    return jsonify({
        "clubs": clubs,
        "club_dict": {c["name"]: c["category"] for c in clubs},
    })


@app.post("/api/logs")
def api_create_log():
    """활동일지 작성."""
    data = request.get_json(silent=True) or {}
    ok, message, result = log_service.create_log(data)
    status = 200 if ok else 400
    return jsonify({"ok": ok, "message": message, "result": result}), status


@app.get("/api/logs/download")
def api_download_log():
    """활동일지 엑셀 다운로드."""
    try:
        output, filename = log_service.export_excel()
        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as err:  # noqa: BLE001
        return jsonify({"error": str(err)}), 500


# ======================================================================
#  공개 API — 주간 활동 여부
# ======================================================================
@app.get("/api/weekly")
def api_weekly_info():
    """현재 등록 대상 주 정보 반환."""
    return jsonify(weekly_service.get_week_info())


@app.post("/api/weekly")
def api_create_weekly():
    """주간 활동 여부 등록."""
    data = request.get_json(silent=True) or {}
    ok, message, result = weekly_service.create_weekly(
        data.get("club_name", ""),
        data.get("activity_status", "동아리 활동 일정 없음"),
        data.get("club_auth", ""),
    )
    status = 200 if ok else 400
    return jsonify({"ok": ok, "message": message, "result": result}), status


@app.get("/api/weekly/download")
def api_download_weekly():
    """주간 활동 여부 엑셀 다운로드."""
    try:
        output, filename = weekly_service.export_excel()
        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as err:  # noqa: BLE001
        return jsonify({"error": str(err)}), 500


# ======================================================================
#  관리자 인증
# ======================================================================
@app.post("/api/admin/login")
def api_login():
    """관리자 로그인. 성공 시 세션에 표시."""
    data = request.get_json(silent=True) or {}
    if data.get("password") == config.ADMIN_PASSWORD:
        session["logged_in"] = True
        return jsonify({"ok": True})
    return jsonify({"ok": False, "message": "비밀번호가 틀렸습니다."}), 401


@app.post("/api/admin/logout")
def api_logout():
    """관리자 로그아웃."""
    session.pop("logged_in", None)
    return jsonify({"ok": True})


@app.get("/api/admin/session")
def api_session():
    """현재 로그인 상태 확인 (프론트 라우트 가드용)."""
    return jsonify({"logged_in": bool(session.get("logged_in"))})


# ======================================================================
#  관리자 API — 보호된 라우트
# ======================================================================
@app.get("/api/admin/dashboard")
@login_required
def api_dashboard():
    """관리자 대시보드 통계."""
    total = len(club_service.get_clubs())
    return jsonify(log_service.get_dashboard_stats(total))


@app.get("/api/admin/logs")
@login_required
def api_admin_logs():
    """전체 활동일지 (최신순)."""
    return jsonify({"logs": log_service.get_logs()})


@app.delete("/api/admin/logs")
@login_required
def api_delete_log():
    """활동일지 한 건 삭제 (기록일시 기준)."""
    data = request.get_json(silent=True) or {}
    ok, message = log_service.delete_log(data.get("timestamp", ""))
    return jsonify({"ok": ok, "message": message}), (200 if ok else 400)


@app.get("/api/admin/clubs")
@login_required
def api_admin_clubs():
    """동아리 목록 (인증번호 포함)."""
    df = club_service.get_clubs_with_auth()
    return jsonify({"clubs": df.fillna("").astype(str).to_dict("records")})


@app.post("/api/admin/clubs")
@login_required
def api_add_club():
    """동아리 추가."""
    data = request.get_json(silent=True) or {}
    ok, message = club_service.add_club(
        data.get("name", ""), data.get("category", "")
    )
    return jsonify({"ok": ok, "message": message}), (200 if ok else 400)


@app.delete("/api/admin/clubs")
@login_required
def api_delete_club():
    """동아리 삭제."""
    data = request.get_json(silent=True) or {}
    ok, message = club_service.delete_club(data.get("name", ""))
    return jsonify({"ok": ok, "message": message}), (200 if ok else 400)


@app.get("/api/admin/weekly")
@login_required
def api_admin_weekly():
    """주간 입력 설정 페이지 데이터."""
    df = club_service.get_clubs_with_auth()
    return jsonify({
        "clubs": df.fillna("").astype(str).to_dict("records"),
        "weekly_logs": weekly_service.get_weekly_logs(),
    })


if __name__ == "__main__":
    app.run(debug=True, port=5015)